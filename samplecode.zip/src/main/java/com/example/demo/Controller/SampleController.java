package com.example.demo.Controller;


import com.example.demo.Controller.Request.UserRegistration;
import com.example.demo.Controller.Response.GeneralResponse;
import com.example.demo.Service.SampleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("sample")
public class SampleController {
    @Autowired
    SampleService sampleService;//injecting the service dependency in the controller using autowired.

    @GetMapping("sample")
    public String getName(){
        //return  "sample name";
        return "sample-sample controller testing--GET";
    }


    @GetMapping("sample_service")
    public String sample_service(){
        return sampleService.getString();//calling service from the controller.
    }
    @GetMapping("checkChildAge")
    public ResponseEntity<?> sample_service(@RequestParam int age){
        GeneralResponse gen = new GeneralResponse();
        try{
            String message = sampleService.checkChildAge(age);//calling service from the controller.
            gen.setMessage(message);
            return ResponseEntity.ok(gen);
        }catch (Exception e){
            gen.setMessage(e.getMessage());
            return ResponseEntity.badRequest().body(gen);
        }
    }

    @PostMapping("sample")
    public String postName(){
        //return  "sample name";
        return "sample controller testing--POST";
    }
    @PostMapping("sample_post")
    public String samplePost(){
        return "sample controller testing-post ";
    }

    @PostMapping("sample_path_variable/{user_id}")
    public String pathvariable(@PathVariable String user_id){
        System.out.println("User id "+user_id);
        return "sample controller testing--POST";
    }
    @PostMapping("sample_req_param")
    public String req_param(@RequestParam String email,
                            @RequestParam String password){
        System.out.println("Email "+email+" Password "+password);
        return "sample controller testing--POST";
    }

    @PostMapping("sample_file_upload")
    public String req_param(@RequestParam MultipartFile file){
        System.out.println(file.getOriginalFilename());
        return "FIle name is "+file.getOriginalFilename();
    }

    @PostMapping("sample_req_body")
    public String req_body(@RequestBody String data){
        System.out.println("req_body "+data);
        return "sample controller testing--POST";
    }
    @PostMapping("register")
    public ResponseEntity<?> user_registration(@RequestBody UserRegistration obj){
        GeneralResponse res = new GeneralResponse();
        try{
            sampleService.userRegistration(obj);
            res.setMessage("user Registration ");
            return ResponseEntity.ok(res);//200 status code response.
        }catch (Exception e){
            res.setMessage(e.getMessage());
            return  ResponseEntity.badRequest().body(res);//400 status code response
        }

    }
    @PostMapping("user_update/{user_id}")
    public String user_update(@PathVariable String user_id,
                              @RequestBody UserRegistration obj){
        System.out.println("user_id "+user_id);
        System.out.println(obj.getFirst_name());
        System.out.println(obj.getLast_name());
        System.out.println(obj.getMobile());
        System.out.println(obj.getCity());
        System.out.println(obj.getDob());
        System.out.println(obj.getFather_name());
        System.out.println(obj.getAddress());
        System.out.println(obj.getEmaill());

        return "User Registration successfull.";
    }



}
