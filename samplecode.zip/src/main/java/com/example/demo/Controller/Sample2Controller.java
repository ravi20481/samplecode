package com.example.demo.Controller;

import com.example.demo.Controller.Request.UserRegistration;
import com.example.demo.Controller.Response.GeneralResponse;
import com.example.demo.Model.CityModel;
import com.example.demo.Service.SampleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("sample2")
public class Sample2Controller {
    @Autowired
    SampleService sampleService;
    @GetMapping("sample")
    public String getName2(){
        //return  "sample name";
        return "sample2---sample controller testing--GET";
    }
    @GetMapping("getCityList")
    public ResponseEntity<?> getCityList(){
        return ResponseEntity.ok(sampleService.getCityList());
        //return "sample response";
    }
    @GetMapping("getPersonList")
    public String getPersonList(){
        sampleService.getPersonList();
        return "sample response";
    }
    @PostMapping("register")
    public ResponseEntity<?> user_registration(@RequestBody UserRegistration obj){
        GeneralResponse res = new GeneralResponse();
        //res.setMessage("successful register");
        res.setMessage("failure register");
        //return ResponseEntity.ok(res);//for success response
        return ResponseEntity.badRequest().body(res);
    }
}
