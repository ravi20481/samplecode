package com.example.demo.Service;


import com.example.demo.Controller.Request.UserRegistration;
import com.example.demo.Model.CityModel;
import com.example.demo.Model.PersonModel;
import com.example.demo.Repo.CItyRepo;
import com.example.demo.Repo.PersonRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SampleService {
    //injecting the dependency in the service
    @Autowired
    CItyRepo cityRepo;
    @Autowired
    PersonRepo personRepo;

    public String getString(){
        return "sample response from the service.";
    }

    public boolean userRegistration(UserRegistration obj) throws Exception{
//        System.out.println(obj.getFirst_name());
//        System.out.println(obj.getLast_name());
//        System.out.println(obj.getMobile());
//        System.out.println(obj.getCity());
//        System.out.println(obj.getDob());
//        System.out.println(obj.getFather_name());
//        System.out.println(obj.getAddress());
//        System.out.println(obj.getEmaill());
        if(obj.getFirst_name() == null || obj.getFirst_name().equals("")){
            throw new Exception("Service::User Registration failure");
            //return false;
        }else{
            return  true;
        }
    }

    public  List<CityModel> getCityList(){
        /*
            getting the data from city table and print in the console.
         */
        List<CityModel> obj = cityRepo.findAll();//get the data from the city table
//        //iteration the data from the list
//        obj.forEach(o->{
//            System.out.println(o.getId()+" "+o.getName());
//        });
        return obj;
    }
    public void getPersonList(){
        /*
            getting the data from city table and print in the console.
         */
        List<PersonModel> obj = personRepo.findAll();//get the data from the city table
        //iteration the data from the list
        obj.forEach(o->{
            System.out.println(o.getPerson_id()+" "+o.getEmail());
        });
    }

    public String checkChildAge(int age)throws  Exception{
        if(age >10){
            ///throw error
            throw new Exception("This is not child");
        }else {
            return "this is child";//return string
        }
    }


}
